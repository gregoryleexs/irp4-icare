#include "parameters.h"

void setup_ultrasonic();
float readUltrasonic();
