#include "parameters.h"

String generateHTTPHeader(int contentLength);
String generateJSON(float thermometer, float humidity, float ambient_temperature, float ultrasonic, bool fallDetected);
