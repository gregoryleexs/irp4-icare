// Additional read on https://learn.adafruit.com/dht?view=all
#include "dht11.h"

DHT dht(DHTPIN, DHTTYPE);

void setup_dht() {
  dht.begin();
}

// readAmbientHumidity on dht11
// return value
// return -1 on error
float readAmbientHumidity() {
  float h = dht.readHumidity();  // Sensor readings may also be up to 2 seconds 'old' (its a very slow sensor)
  if (isnan(h)) {                // invalid value returned
    Serial.println(F("ERROR!!!... Failed to read from DHT sensor!"));
    return -1;
  }
  Serial.print(F(" Humidity (%): "));
  Serial.println(h);
  return h;
}

// readAmbientTemperature on dht11
// return value
// return -1 on error
float readAmbientTemperature() {
  float t = dht.readTemperature();  // Read temperature as Celsius (the default)
  if (isnan(t)) {                   // invalid value returned
    Serial.println(F("ERROR!!!... Failed to read from DHT sensor!"));
    return -1;
  }
  Serial.print(F("Ambient temperature (°C): "));
  Serial.println(t);
  return t;
}
