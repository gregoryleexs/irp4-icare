#include <Arduino.h>

//define hardware pins
#define rxPin 2           // ESP-01
#define txPin 3           // ESP-01
#define echoPin 4         // HC-SR04
#define trigPin 5         // HC-SR04
#define DHTPIN 6          // DHT11
#define DHTTYPE DHT11     // DHT11
#define buzzer 8          //General
#define led13 13          // counter board
#define clockPin 12       // counter board
#define dataPin 11        // counter board
#define latchPin 10       // counter board
#define pushbutton_S1 9   // counter board
#define pushbutton_S2 A0  // counter board

//Student information
#define STUDENT_NAME "Gregory Lee"
#define STUDENT_ID "S10239908G"
#define CLASS_ID "PA11"
#define GROUP_ID "Group 1"

//Network and gateway information
#define SSID_NAME "npiot1"                          // your network SSID (name)
#define SSID_PASS "soe040401"                       // your network password
#define HTTP_SERVER "postman-echo.com"              // your http server URL;
#define HTTP_PORT 80                                // your http server port;
#define HTTP_SERVER_ENDPOINT "POST /post HTTP/1.1"  // your http server endpoint;
