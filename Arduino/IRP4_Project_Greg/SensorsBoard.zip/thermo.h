#include <Adafruit_MLX90614.h>
#include "parameters.h"

void setup_thermo();
double readThermometer(void);
