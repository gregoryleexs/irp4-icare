#include <DHT.h>
#include "parameters.h"

void setup_dht();
float readAmbientTemperature();
float readAmbientHumidity();
