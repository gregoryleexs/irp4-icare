#include "parameters.h"

void setup_ioboard();
bool readPushButton(int x);
void displayLED(bool status_LED);
void displayNumber(int num);
