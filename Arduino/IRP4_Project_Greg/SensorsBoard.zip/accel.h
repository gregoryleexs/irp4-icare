#include <Adafruit_ADXL345_U.h>
#include "parameters.h"

void setup_accel();
float readAccelerometer();
bool fallDetected();
