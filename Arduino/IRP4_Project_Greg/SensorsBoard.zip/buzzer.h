#include "parameters.h"

void setup_buzzer();
void beep(int x);
void beep();
