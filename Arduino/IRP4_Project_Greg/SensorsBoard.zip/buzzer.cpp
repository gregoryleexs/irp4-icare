#include "buzzer.h"

void setup_buzzer() {
  pinMode(buzzer, OUTPUT);  // General
  beep();                   //beep once
}

// beep on buzzer
void beep(int x) {
  int i = 0;
  while (i < x) {
    beep();
    i++;
  }
}
void beep() {
  digitalWrite(buzzer, HIGH);
  delay(300);
  digitalWrite(buzzer, LOW);
  delay(300);
}
